# Change Log

## head

## v0.0.2
- Remove deprecated content
- fix galaxy.yml

## v0.0.1
- Init release
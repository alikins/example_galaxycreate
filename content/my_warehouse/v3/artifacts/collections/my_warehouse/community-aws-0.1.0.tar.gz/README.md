Ansible Collection: community.aws
=================================================

# Ansible Collection - fvzwieten.starwars

Documentation for the Ansible starwars collection.

This is an example colleciton for training purposes

It contains the following modules:
- movie: 
  Returns title, trilogy and trilogy-sequence from given input movie number and numbering scheme (released or chronological)

It contains the following roles:
<none>

It contains the following plugins:
<none>

It contains the following playbooks:
<none>


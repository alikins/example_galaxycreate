# Contributing to the Ansible Security Automation Collection

Thanks for your interest in the Ansible Security Automation collection.  Before considering contributing, please take a moment to read and sign our <a href="https://github.com/cyberark/conjur/blob/master/Contributing_OSS/CyberArk_Open_Source_Contributor_Agreement.pdf" download="conjur_contributor_agreement">Contributor Agreement</a>. This provides patent protection for all CyberArk Ansible users and allows CyberArk to enforce its license terms.

## Pull Request Workflow

Currently, this repository is source-available and not open to contributions.  Please continue to follow this repository for updates and open-source availability

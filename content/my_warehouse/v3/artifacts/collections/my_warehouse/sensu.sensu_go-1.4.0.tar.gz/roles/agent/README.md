# sensu.sensu_go.agent role

Visit [the official documentation site][docs] for role documentation.

   [docs]: https://sensu.github.io/sensu-go-ansible/roles/agent.html

# sensu.sensu_go.install role

Visit [the official documentation site][docs] for role documentation.

   [docs]: https://sensu.github.io/sensu-go-ansible/roles/install.html

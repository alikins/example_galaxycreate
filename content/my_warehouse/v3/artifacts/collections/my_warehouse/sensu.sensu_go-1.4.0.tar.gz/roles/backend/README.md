# sensu.sensu_go.backend role

Visit [the official documentation site][docs] for role documentation.

   [docs]: https://sensu.github.io/sensu-go-ansible/roles/backend.html

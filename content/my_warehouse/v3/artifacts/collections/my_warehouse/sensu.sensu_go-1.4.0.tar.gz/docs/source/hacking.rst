Developing Sensu Go Ansible Collection
======================================

So, you have decided to help us out. Great! Let us set up a development
environment together, and then we can start hacking ;)


.. toctree::
   :maxdepth: 1
   :caption: Content

   hacking/setup
   hacking/testing
   hacking/documentation
   hacking/releases

Roles
=====

Sensu Go Ansible Collection contains three roles that allow us install and
configure Sensu Go backend and agents.

.. toctree::
   :glob:
   :maxdepth: 1

   roles/*
